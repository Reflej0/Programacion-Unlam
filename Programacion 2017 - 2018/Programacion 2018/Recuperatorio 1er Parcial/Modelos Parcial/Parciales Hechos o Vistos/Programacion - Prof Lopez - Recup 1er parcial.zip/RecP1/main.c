#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

//int cantCaracteresMaxPal(char *, int *);
//int esBlanco(char);
//int esLetra(char);

/* Esto es una combinaci�n de ejercicios de la gu�a, as� que borr� las resoluciones y s�lo dej� las cabeceras de las funciones
 * que us�, ya que en el ex�men uno no resuelve de la forma m�s �ptima. Cualquier consulta enviame un email.
 * Hern�n Funes - hfunesunlam@gmail.com
 */

int main()
{
   char  texto[] = { "  Ahora, justamente,,,,,,, voy a solucionarrr lo que tengo que hacer." };
//   int   veces,
//         tamPalMax = cantCaracteresMaxPal(texto, &veces);

//   printf("La palabra m�s larga tiene %d caracteres\n"
//          "Hay %d palabras con esa cantidad de caracteres\n",
//          tamPalMax,
//          veces);

   return 0;
}

//int cantCaracteresMaxPal(char *cadena, int *veces){
//}
//
//int esBlanco(char caracter){
//}
//int esLetra(char caracter){
//}


