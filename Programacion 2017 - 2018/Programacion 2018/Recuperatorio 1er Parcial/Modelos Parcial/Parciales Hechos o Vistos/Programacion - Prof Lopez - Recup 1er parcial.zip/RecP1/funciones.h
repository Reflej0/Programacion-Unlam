#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

#include <stdlib.h>

int cantCaracteresMaxPal_2(const char *cad, int *veces);


#endif // FUNCIONES_H_INCLUDED
