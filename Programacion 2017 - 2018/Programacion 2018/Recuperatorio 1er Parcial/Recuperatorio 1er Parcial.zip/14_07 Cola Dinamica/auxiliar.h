#ifndef AUXILIAR_H_INCLUDED
#define AUXILIAR_H_INCLUDED

typedef int T_dato;

#endif // AUXILIAR_H_INCLUDED
