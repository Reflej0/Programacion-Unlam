#ifndef AUXILIARES_H_INCLUDED
#define AUXILIARES_H_INCLUDED

typedef struct
{
    int clave;
    int dni;
} T_dato;

#endif // AUXILIARES_H_INCLUDED
