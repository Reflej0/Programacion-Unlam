#include "info.h"
#include "lista.h"
#include "biblioteca.h"
#define TAM 31

int leerArchivoYCargarLista(FILE *fp, t_lista *p)
{
    char linea[TAM+1], *aux;
    t_info nov;
    int cont=0;

    while (fgets(linea,TAM+1,fp)) //agarro una linea del archivo
    {
        cont++;
        aux=strrchr(linea,'\n'); //Manda direccion de memoria a ultima ocurrencia de \n
            if (aux == NULL)
            {
                fclose(fp);
                fprintf(stderr,"ERROR: No se encontro nada, che\n" ); //Esta recibiendo el NULL del fallo de fgets
                exit (1);
            }
        //char *aux=strrchr(linea,'\n');
        //char *aux=linea+TAMTOT;
        *aux='\0';
        //Reg
        aux-=1;
        sscanf(aux,"%d",&nov.nroReg);
        *aux='\0';
        //Prec
        aux-=10;
        sscanf(aux,"%f",&nov.precio);
        *aux='\0';
        //Cantidad
        aux-=13;
        sscanf(aux,"%f",&nov.canti);
        *aux='\0';
        //Clave                //Este es especial por ser chars
        aux-=6;
        strcpy(nov.clave,aux);
        *aux='\0';
        if(nov.precio==0)   //Si el precio es 0, es un pedido y debo almacenar como negativo
            nov.canti=0-nov.canti;
        /*printf("CLAVE:%s\n",nov.clave);
        printf("CANTIDAD:%f\n",-nov.canti);
        printf("PRECIO:%f\n",nov.precio);           //Para ver si anda esta garcha
        printf("NUM DE REGISTRO:%d\n",nov.nroReg);
        printf("\n");*/
        insertarAlFinal(p,&nov);    //agrega al final de la lista un nodo con info que acabo de parsear de archivo
        if(listaLlena(p))   //Si la lista esta llena (o sea, sin memoria) chau.
            exit(1);
    }

    return cont;
}

int eliminarDuplicados(t_lista *p)
{
t_lista *q; //otro puntero que va a comparar todos nodos con primero
t_nodo *aux;
int cont=0;

while(*p)
{
    q=&(*p)->sig; //asigno a puntero q el siguiente a p
        while(*q) //mientras haya siguiente (En algun momento va a ser NULL)
        {
            while((*q) && !comparar(&(*p)->info,&(*q)->info)) //Mientras sean iguales
            {
                acumularYMaxPrecio(&(*p)->info,&(*q)->info); //modifico primer dup encontrado acumulando data de los demas
                cont++;
                aux=*q; //asigno el q que voy a eliminar a un aux
                *q=aux->sig; //"conecto" el siguiente al que borre como sig de p
                free(aux); //borra
            }
            if(*q)  //Si es el ultimo nodo, no asigno *q->sig otra vez porque sino explota
                q=&(*q)->sig; //asigno a q el siguiente a si mismo para que siga recorriendo, excepto que sea el ultimo
        }
    p=&(*p)->sig; //nuevo comienzo de lista porque ya recorri todo comparando con una clave
}
return cont;
}

int comparar(const t_info *n1,const  t_info *n2)
{
    return(strcmp(n1->clave,n2->clave)); //Comparo claves
}

void acumularYMaxPrecio( t_info *n1, t_info *n2)
{
    n1->canti+=n2->canti; //sumo cantidades
    if(n1->precio<=n2->precio) //Dejo el importe maximo en nodo donde acumulo
    n1->precio=n2->precio;
}


int sacarDeListaYActualizarArchivo(FILE *fp, t_lista *d)
{
    t_exist data;
    t_info reg;
    int cont=0;

    while(!listaVacia(d))   //mientras haya lista
    {
        sacarPrimeroLista(d,&reg); //recupero info de un nodo de la lista en struct reg y lo borro
        fseek(fp,sizeof(t_exist)*(reg.nroReg-1),SEEK_SET); //t_exist en lineas 0,1,7,6, que son las posiciones de los registros en el archivo a modificar
        fread(&data,sizeof(data),1,fp); //leo ese registro del archivo y mando a struct data
        //modifico reg a guardar en archivo
        data.exist+=reg.canti;
        if(reg.precio>=data.precio)
            data.precio=reg.precio;
        // ya modifique, ahora guardo
        fseek(fp,-1L*(sizeof(t_exist)),SEEK_CUR); //me posiciono para grabar encima despues de haber leido registro
        fwrite(&data,sizeof(t_exist),1,fp); //grabo
        fseek(fp,0L,SEEK_CUR); //si o si dsp de fwrites
        cont++;
    }
    return cont;
}


