#ifndef DEFS_H
#define DEFS_H


#define DUPLICADO 0
#define SIN_MEM 1
#define TODO_OK 2
#define TAM 500
#define VERDADERO 1
#define FALSO 0


#endif // DEFS_H
