#include <Cola.h>



void crear_cola(t_cola* pcola)
{
	///Inserte el c�digo ac�
}



int poner_en_cola(t_cola* pcola, const t_dato* pd)
{
	///Inserte el c�digo ac�
}



int sacar_de_cola(t_cola* pcola, t_dato* pd)
{
	///Inserte el c�digo ac�
}



void vaciar_cola(t_cola* pcola)
{
	///Inserte el c�digo ac�
}
