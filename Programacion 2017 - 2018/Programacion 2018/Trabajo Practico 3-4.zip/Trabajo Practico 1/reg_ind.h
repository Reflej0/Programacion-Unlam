#ifndef REG_IND_H_INCLUDED
#define REG_IND_H_INCLUDED

///UBICADO ACA PARA QUE NO ENTRE EN CONFLICTO CON LISTA.H - INDICE.H o ITERADOR.H

typedef struct
{
    long dni;
    unsigned nro_reg;
} t_reg_indice;

#endif // REG_IND_H_INCLUDED
