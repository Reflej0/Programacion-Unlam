#ifndef CADENAS_H_
#define CADENAS_H_

#include <stdlib.h>

int buscarYReemp(char *s, const char *b, const char *r);

/** debe declarar y desarrollar su propia versi�n de buscar y reemplazar:
int buscarYReemp_Mio(char *s, const char *b, const char *r);
**/


#endif
