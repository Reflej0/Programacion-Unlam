#ifndef MAIN_H_
#define MAIN_H_

#include <stdio.h>

#include "cadenas.h"


void prue1();
void prue2();
void prue3();
void prue4();
void prue5();
void prue6();

void mostrarAntes(const char *caso,
                  const char *bus, const char *ree,
                  const char *cad);
void mostrarDespues(const char *cad, int veces);


#endif // MAIN_H_
