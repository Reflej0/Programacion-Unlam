
#include "cadenas.h"



/** debe declarar y desarrollar su propia versi�n de buscar y reemplazar:
int buscarYReemp_Mio(char *s, const char *b, const char *r)
{
    ...
}
**/

