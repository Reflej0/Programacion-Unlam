
#include "main.h"



int main()
{
    prue1();
    prue2();
    prue3();
    prue4();
    prue5();
    prue6();

    return 0;
}


void prue1()
{
    char    cad[500] = { "Que te digan aquello, quiere decir que no queremos "
                         "porque aquello es nocivo" },
            bus[] = { "qUe" },
            ree[] = { "Porque" };
    int     veces;

    mostrarAntes("1er caso.", bus, ree, cad);
    veces = buscarYReemp(cad, bus, ree);
    mostrarDespues(cad, veces);
}

void prue2()
{
    char    cad[500] = { "Que te digan aquello, quiere decir que no queremos "
                         "porque aquello es nocivo" },
            bus[] = { "qUe " },
            ree[] = { "K " };
    int     veces;

    mostrarAntes("2do caso.", bus, ree, cad);
    veces = buscarYReemp(cad, bus, ree);
    mostrarDespues(cad, veces);
}

void prue3()
{
    char    cad[500] = { "Que te digan aquello, quiere decir que no queremos "
                         "porque aquello es nocivo" },
            bus[] = { " QuE " },
            ree[] = { " K " };
    int     veces;

    mostrarAntes("3er caso.", bus, ree, cad);
    veces = buscarYReemp(cad, bus, ree);
    mostrarDespues(cad, veces);
}

void prue4()
{
    char    cad[500] = { "Que te digan aquello, quiere decir que no queremos "
                         "porque aquello es nocivo" },
            bus[] = { "QuE " },
            ree[] = { "??? " };
    int     veces;

    mostrarAntes("4to caso.", bus, ree, cad);
    veces = buscarYReemp(cad, bus, ree);
    mostrarDespues(cad, veces);
}

void prue5()
{
    char    cad[500] = { "Que te digan aquello, quiere decir que no queremos "
                         "porque aquello es nocivo" },
            bus[] = { "" },
            ree[] = { "pArAgUaY" };
    int     veces;

    mostrarAntes("5to caso.", bus, ree, cad);
    veces = buscarYReemp(cad, bus, ree);
    mostrarDespues(cad, veces);
}

void prue6()
{
    char    cad[500] = { "Que te digan aquello, quiere decir que no queremos "
                         "porque aquello es nocivo" },
            bus[] = { "quE " },
            ree[] = { "" };
    int     veces;

    mostrarAntes("6to caso.", bus, ree, cad);
    veces = buscarYReemp(cad, bus, ree);
    mostrarDespues(cad, veces);
}

void mostrarAntes(const char *caso,
                  const char *bus, const char *ree,
                  const char *cad)
{
    printf("%s\n"
           "Buscando \"%s\" y reemplazando por \"%s\" en:\n"
           "\"%s\"\n",
           caso,
           bus, ree,
           cad);

}
void mostrarDespues(const char *cad, int veces)
{
    char    cadVeces[10];

    itoa(veces, cadVeces, 10);
    printf("%se hi%s %s reemplazo%s resultando:\n"
           "\"%s\"\n\n",
           veces == 0 ? "No s" : "S",
           veces > 1 ? "cieron" : "zo",
           veces ? cadVeces : "ningun",
           veces > 1 ? "s" : "",
           cad);
}
