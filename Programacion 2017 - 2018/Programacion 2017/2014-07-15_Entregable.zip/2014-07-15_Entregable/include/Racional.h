#ifndef RACIONAL_H
#define RACIONAL_H


class Racional
{
    private:
    int num;
    int den;

    public:

        Racional::Racional () {this.num=0, this.den=0;};
        Racional::Racional ( a,  b);

};

#endif // RACIONAL_H
