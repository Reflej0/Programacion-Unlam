#ifndef DEFS_H
#define DEFS_H


#define DUPLICADO 0
#define TODO_OK 1
#define SIN_MEM 2
#define VERDADERO 1
#define FALSO 0


#endif // DEFS_H
