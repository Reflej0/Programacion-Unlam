#include <Racional.h>
Racional:: Racional (int num, int den)
{

}
