#include <iostream>
#include "racional.h"

int main()
{
    Racional n1(10.45);
    Racional n2(1.1);
    cout << n1 << '\n';
    cout << n2 << '\n';
    /*cout << n1+n2 << '\n';
    cout << n1-n2 << '\n';
    cout << n1*n2 << '\n';
    cout << n1/n2 << '\n';*/
}
