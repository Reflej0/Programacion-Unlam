#ifndef INFO_H
#define INFO_H

#include <stdio.h>

#define NOM_ARCH "archivo"

/* para el archivo */
typedef struct
{
   char  desProd[37];
   char  claProd[7];
   float precio;
} t_registro;

/* para el arbol */
typedef struct
{
   int   nroReg;
   float porcentaje;
} t_info;

int actualizarArchivo_2(FILE *fp, const t_info *d);

void mostrarReg(const t_registro *d);
void mostrarInfo(const t_info *d);
int generarArchivo(const char *nomArch);
int mostrarArch(const char *nomArch);
int generarArchivo(const char *nomArch);


#endif // INFO_H
