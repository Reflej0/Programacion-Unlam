#include <stdio.h>
#include <stdlib.h>

#include "info.h"
#include "arbol.h"



/* funciones a desarrollar:
 *    recorrerYVaciarArbolYActArchivo
 *    actualizarArchivo
 */

int recorrerYVaciarArbolYActArchivo(t_arbol *p, FILE *fp);
int actArch(FILE* fp,const t_info* d);
int main()
{
   FILE *fpProductos;
   t_arbol arbol;
   int cant;

   crearArbol(&arbol);

   /** inicio de crear el lote de prueba **/
   cant = cargarArbol(&arbol);
   printf("Se generaron %d nodos en el arbol\n", cant);
   cant = mostrarArbolEnPreOrden(&arbol);
   printf("Se mostraron %d nodos del arbool\n", cant);
   cant = generarArchivo(NOM_ARCH);
   printf("Se grabaron %d registros en el archivo\n", cant);
   cant = mostrarArch(NOM_ARCH);
   printf("Se mostraron %d registros del archivo\n", cant);
   /** fin de crear el lote de prueba **/

   fpProductos = fopen(NOM_ARCH, "r+b");
   if(fpProductos == NULL)
   {
      fprintf(stderr, "ERROR abriendo archivo");
      return 1;
   }

   cant =recorrerYVaciarArbolYActArchivo(&arbol,fpProductos);/*recorrerYVaciarArbolYActArchivo_2(&arbol,
                                            fpProductos,
                                            actualizarArchivo_2);*/
   printf("Se eliminaron y actualizaron %d nodos del arbol"
          " y registros en el archivo\n", cant);

   fclose(fpProductos);
   mostrarArch(NOM_ARCH);
   return 0;
}

int recorrerYVaciarArbolYActArchivo(t_arbol *p, FILE *fp)
{
    if(*p)
    {
        actArch(fp,&(*p)->info);
        int cant=recorrerYVaciarArbolYActArchivo(&(*p)->izq,fp)+recorrerYVaciarArbolYActArchivo(&(*p)->der,fp);
        free(*p);
        *p=NULL;
        return cant+1;
    }
    return 0;
}
int actArch(FILE* fp,const t_info* d)
{
    t_registro reg;

    fseek(fp,(d->nroReg-1)*sizeof(t_registro),SEEK_SET);
    fread(&reg,1,sizeof(t_registro),fp);

    reg.precio=(reg.precio+(reg.precio*(d->porcentaje/100)));

    fseek(fp,-(long)sizeof(t_registro),SEEK_CUR);
    fwrite(&reg,sizeof(t_registro),1,fp);

    return 1;

}
