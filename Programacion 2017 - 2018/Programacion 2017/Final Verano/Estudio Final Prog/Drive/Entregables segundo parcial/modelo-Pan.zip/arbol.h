#ifndef ARBOL_H
#define ARBOL_H

#include <stdio.h>
#include <stdlib.h>


#include "info.h"

#define SIN_MEM            0
#define CLA_DUP           -1
#define TODO_BIEN          1


/** para los nodos */
typedef struct s_nodo
{
   t_info info;
   struct s_nodo *izq,
                 *der;
} t_nodo;

/** el �rbol */
typedef t_nodo *t_arbol;

void crearArbol(t_arbol *p);

int cargarArbol(t_arbol *p);


int recorrerYVaciarArbolYActArchivo_2(t_arbol *p, FILE *fp,
                                      int (*actArch)(FILE *, const t_info*));

int mostrarArbolEnPreOrden(const t_arbol *p);


#endif // ARBOL_H

