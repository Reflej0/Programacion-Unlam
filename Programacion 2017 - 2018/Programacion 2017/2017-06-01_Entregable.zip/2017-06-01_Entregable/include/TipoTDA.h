#ifndef TIPOTDA_H
#define TIPOTDA_H

#include <TiposDelivery.h>


typedef t_receta t_dato;


#endif // TIPOTDA_H
