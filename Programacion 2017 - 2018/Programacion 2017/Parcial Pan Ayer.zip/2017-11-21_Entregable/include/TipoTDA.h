#ifndef TIPOTDA_H
#define TIPOTDA_H

#include <UtilitariasMuebles.h>

typedef t_reg_ind t_dato_arbol;

typedef t_transferencia t_dato_lista;

#endif // TIPOTDA_H
