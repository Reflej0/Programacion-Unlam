#include <iostream>
#include <stdlib.h>
#include "hora.h"

using namespace std;

void probarHora(int hh, int mm, int ss, int segundos)
{
    Hora h1(hh, mm, ss);
    Hora h2(segundos);
    Hora h3(h1 * 3);
    Hora h4(3 * h3);
    Hora h5;

    cout << "h1 = " << h1 << endl << "h2 = " << h2 << endl << "h3 = " << h3 << endl << "h4 = " << h4 << endl << "h5 = " << h5 << endl << endl;
    h5 = h2 += h3 += h4 +=ss;
    cout << "h1 - h2 =" << h1 - h2 << endl;
    cout << "h1 = " << h1 << endl << "h2 = " << h2 << endl << "h3 = " << h3 << endl << "h4 = " << h4 << endl << "h5 = " << h5 << endl << endl;
}

int main()
{
    int horas = 0;
    int minutos = 0;
    int segundos = 1;
    probarHora(horas, minutos, segundos, segundos);
}
