#ifndef SEPARADOR_H_INCLUDED
#define SEPARADOR_H_INCLUDED

void reemplazar_separador(char* frase);

size_t _strlen(const char* frase);

void _strcpy(char* destino, const char* origen);

#endif // SEPARADOR_H_INCLUDED
