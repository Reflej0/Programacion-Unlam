#ifndef VOCALES_H_INCLUDED
#define VOCALES_H_INCLUDED

int cantidad_palabras_4_mas_vocales(char* frase);

#endif // VOCALES_H_INCLUDED
