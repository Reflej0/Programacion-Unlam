#include"matrices.h"

int sumaElemPorDebajoDiagPrincSecu(int m[][COL],int fil,int col)
{
    int i,j,resul=0;
    for(i=fil-1;i>fil/2;i--)
        for(j=1;j<col-1;j++)
            resul+=m[i][j];
    return resul;
}
