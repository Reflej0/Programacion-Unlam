#ifndef MATRICES_H_INCLUDED
#define MATRICES_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#define FIL 6
#define COL 6

int sumaElemPorDebajoDiagPrincSecu(int[][COL],int,int);

#endif // MATRICES_H_INCLUDED
