#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <utilitarias.h>
#include <banco.h>
char * dirDelUltimo(char *c)
{
    char *fin=c;
    while(*fin)
        fin++;
    fin-=2;
    return fin;
}
void invertir(char *ini,char *fin)
{
    char aux,*auxiliar=fin,*inicio=ini;
    while(inicio < auxiliar)
    {
        aux= *auxiliar;
        *auxiliar=(*inicio);
        (*inicio)=aux;
        (inicio)++;
        auxiliar--;
    }
}
void texto_a_movimiento(const char * cadena,t_movimiento_banco * pmov)
{

    sscanf(cadena,"%8s%c%f",pmov->cod_cta,&pmov->tipo_mov,&pmov->importe);
    pmov->cod_cta[8]=pmov->cod_cta[7];
    pmov->cod_cta[7]='/';

}

/*char * encriptar (char * cad, int linea, const char * clave)
{
    char *inicioPK=(char*)clave;
    if(linea%2!=0)
        invertirCadena(&cad);
    int num = *cad - '0';
    invertir(&cad+1,&cad+num,num);
    char *fin=dirUltimoElem(cad);
    fin--;
    num=*fin - '0';
    invertir(&fin,&fin-num,num);
    char *aux=cad;
    while(*aux)
    {
        if(!*inicioPK)
            inicioPK=(char*)clave;
        *aux += *inicioPK-'a';
        inicioPK++;
        aux++;
    }
    return cad;
}*/
char * desencriptar (char * cad, int linea, const char * clave)
{
    char *inicioPK=(char*)clave;
    char *aux=cad,*inicio=cad;
    while(*aux)
    {
        if(!*inicioPK)
            inicioPK=(char*)clave;
        *aux -= *inicioPK-'a';
        inicioPK++;
        aux++;
    }
    char *fin=dirDelUltimo(cad);
    int num=*fin-'0';
    invertir(fin-num,fin-1);
    num=*cad-'0';
    invertir(cad+1,cad+num);
    if(linea%2!=0)
        invertir(cad,fin);
    return inicio;
}
