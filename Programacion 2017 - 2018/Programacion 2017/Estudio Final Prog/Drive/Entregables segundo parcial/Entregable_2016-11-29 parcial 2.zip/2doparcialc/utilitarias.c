#include<utilitarias.h>
#include<string.h>
#include<varias.h>
#include<ctype.h>

void validar_arbol(const t_arbol * pa)
{
    ///Ingrese el c�digo Aqu�
}

int informe_materias_aprobadas(const t_arbol *pa)
{
    ///Ingrese el c�digo Aqu�
    return NO_EXISTE;
}
