#include<stdlib.h>
#include<cola.h>
void crear_cola(t_cola* pc)
{
    ///Ingrese el c�digo Aqu�
}
int poner_en_cola(t_cola* pc, const t_info_cola* pd)
{
    ///Ingrese el c�digo Aqu�
    return FALSO;
}
int sacar_de_cola(t_cola* pc, t_info_cola* pd)
{
    ///Ingrese el c�digo Aqu�
    return FALSO;
}
int frente_de_cola(const t_cola* pc, t_info_cola* pd)
{
    ///Ingrese el c�digo Aqu�
    return FALSO;
}
int cola_vacia(const t_cola* pc)
{
    ///Ingrese el c�digo Aqu�
    return FALSO;
}
int cola_llena(const t_cola* pc)
{
    ///Ingrese el c�digo Aqu�
    return FALSO;
}
void vaciar_cola(t_cola* pc)
{
    ///Ingrese el c�digo Aqu�
}
