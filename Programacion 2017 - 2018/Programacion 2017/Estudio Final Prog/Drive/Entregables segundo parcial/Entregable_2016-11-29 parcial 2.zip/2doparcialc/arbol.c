#include <Tipos.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <Arbol.h>

int es_arbol_avl(const t_arbol* pa)
{
    ///Ingrese el c�digo Aqu�
    return FALSO;
}

int es_arbol_balanceado(const t_arbol* pa)
{
    ///Ingrese el c�digo Aqu�
    return FALSO;
}

int es_arbol_completo(const t_arbol* pa)
{
    ///Ingrese el c�digo Aqu�
    return FALSO;
}

void arbol_grafico(const t_arbol *pa, void (*mostrar_clave)(const t_info *))
{
    ///Ingrese el c�digo Aqu�
}

