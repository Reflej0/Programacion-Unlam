#ifndef SOLUCION2DOPMUEBLES_H
#define SOLUCION2DOPMUEBLES_H


void actualizarDepositos(const char* archTransferencias, const char* archDepositos, const char* archIndDep);
void actualizarDepositos_res(const char* archTransferencias, const char* archDepositos, const char* archIndDep);


#endif // SOLUCION2DOPMUEBLES_H
