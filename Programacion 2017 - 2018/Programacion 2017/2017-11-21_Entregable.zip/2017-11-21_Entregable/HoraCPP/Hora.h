#ifndef HORA_H_INCLUDED
#define HORA_H_INCLUDED
#include <iostream>

using namespace std;

class Hora
{
public:

private:

};

#endif // HORA_H_INCLUDED
