#include <stdio.h>
#include <stdlib.h>
#include <ListaD.h>
#include <Arbol.h>
#include <UtilitariasMuebles.h>
#include <Solucion2doPMuebles.h>



int main()
{
	generarArchivos();

	puts("Archivo Transferencias:");
	puts("Dep Orig | Dep Dest | Cod Prod | Cant");
	mostrar_archivo_transferencias("Transferencias.txt");

	puts("");
	puts("Depositos antes de actualizar:");
	puts("Dep | Producto | Stock");
	mostrar_archivo_depositos("Depositos.dat");

	///actualizarDepositos("Transferencias.txt", "Depositos.dat", "Depositos.idx");
	actualizarDepositos_res("Transferencias.txt", "Depositos.dat", "Depositos.idx");

	puts("");
	puts("Depositos despues de actualizar:");
	puts("Dep | Producto | Stock");
	mostrar_archivo_depositos("Depositos.dat");

	return 0;
}



void actualizarDepositos(const char* archTransferencias, const char* archDepositos, const char* archIndiceDep)
{
	///Inserte el c�digo ac� ...
}
