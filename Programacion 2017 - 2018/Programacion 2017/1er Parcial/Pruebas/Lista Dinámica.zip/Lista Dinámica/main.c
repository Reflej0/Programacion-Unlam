#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

int main()
{
    T_lista lista;
    crear_lista(&lista);
    T_dato dato = 5;
    T_dato dato2 = 3;
    T_dato dato3 = 9;
    T_dato dato4 = 7;
    //T_dato aux = 0;
    agregar_principio(&lista, &dato);
    agregar_principio(&lista, &dato2);
    agregar_final(&lista, &dato3);
    agregar_ordenado(&lista, &dato4, cmp);
    //eliminar_principio(&lista, &aux);
    //eliminar_ultimo(&lista, &aux);
    //eliminar_lista(&lista);
    mostrar_lista(&lista);
    printf("\n--------------ANTES DEL ORDENAMIENTO----------------");
    ordenar_lista(&lista, cmp);
    mostrar_lista(&lista);
}
